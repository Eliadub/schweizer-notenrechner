/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package noten.rechner;

/**
 *
 * @author eliad
 */
public class NotenRechner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    double max = 10;
    double done = 5;
    double note= done * 5 / max + 1;
    
    System.out.println(note);
    System.out.print(note);
    }
    
}
